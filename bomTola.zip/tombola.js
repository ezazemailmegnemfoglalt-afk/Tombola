
let egyesTombola = document.getElementById("kep1");
let gombok = document.getElementById("gombok");
let meger = document.getElementById("meger");
let megerosites = document.getElementById("megerosites");
let elfogad = document.getElementById("elfogad");
let nemfogad = document.getElementById("nemfogad");


let fizetesMenuGombok =  document.getElementById("fizetesMenu");
let ar =  document.getElementById("ar");
let peez =  document.getElementById("peez");
let fizetsz = document.getElementById("fizetsz");
let megsemNem = document.getElementById("megsem");
let fizetted = document.getElementById("fizettel");
let tenylegesFizetesMenu = document.getElementById("tenylegesFizetesMenu");
let kuldes = document.getElementById("kuldesgomb")
let neve = document.getElementById("nev");
let kartyaszam = document.getElementById("kartyaSzam");
let hitkod = document.getElementById("hitKod")
let checkbok = document.getElementById("csecsboksz")

let neved = document.getElementById("nev");
let kartyaSzam = document.getElementById("kartyaSzam");
let hitKod = document.getElementById("hitKod");
let lejDat = document.getElementById("lejDat");
let elfogadPipa = document.getElementById("csecsboksz")

let valasztott = 0;
let ara = 500;
let valasztottGomb = 0;
let adottGomb = null;
let tolasErtek = 1; 
let osszesTombola = 500;

let jobbra = document.getElementById("jobbra")
let balra = document.getElementById("balra");
let gombokHelye = document.querySelector(".container");

let tiltottSzamok = [];

function generalGombok(kezdo) {
    gombokHelye.innerHTML = ''; 
    for (let i = kezdo; i < kezdo + 50 && i <= osszesTombola; i++) {
        let div = document.createElement('div');
        div.className = 'gomb';
        
        let span = document.createElement('span');
        span.textContent = i;
        
        div.appendChild(span);
        div.addEventListener('click', function() {
            Gomb(this);  
        });
        
        gombokHelye.appendChild(div);
        if (tiltottSzamok.includes(i)) {
            div.style.opacity = "0.5";
            div.style.pointerEvents = "none";
        } else {
            div.addEventListener('click', function() {
                Gomb(this);
            });
        }
        
        gombokHelye.appendChild(div);

    }
    

    szamokSzamozasa = document.querySelectorAll("span");
    console.log("Gombok generálva:", kezdo, "-ig", kezdo+19);
}

function Gomb(elem) {
    adottGomb = elem; 
    valasztott = parseInt(elem.querySelector('span').textContent); 
    valasztottGomb = valasztott;
    
    console.log("Kiválasztva:", valasztott);
    console.log("Elem:", adottGomb);
    
    megerosites.style.display = "block";
    meger.textContent = "Biztos, hogy a(z) " + valasztott + ". számot választod?";
}

function Balra() {
    if (tolasErtek > 1) {
        tolasErtek -= 50;
        generalGombok(tolasErtek);
        console.log("Balra - új kezdőérték:", tolasErtek);
    } else {
        console.log("Már az első oldalon vagy!");
    }
}


function Jobbra() {
    if (tolasErtek + 50 <= osszesTombola) {
        tolasErtek += 50;
        generalGombok(tolasErtek);
        console.log("Jobbra - új kezdőérték:", tolasErtek);
    } else {
        console.log("Már az utolsó oldalon vagy!");
    }
}


function elfog() {
    if(elfogad) {
        fizetesMenu();
    }
}

function nemfog() {
    if(nemfogad) {
        console.log("Mégse");
        megerosites.style.display = "none";
    }
}

function fizetesMenu() {
    ar.textContent = "A tombola ára " + ara + " forint lesz";
    console.log("Fizetési menü megnyitva");
    megerosites.style.display = "none";
    fizetesMenuGombok.style.display = "block";
}

function fizettel() {
    if(fizettel) {
        fizetesMenuGombok.style.display = "none";
        
        if (adottGomb) {
            let szam = parseInt(adottGomb.querySelector('span').textContent);
            
            
            if (!tiltottSzamok.includes(szam)) {
                tiltottSzamok.push(szam);
            }
            
            
            adottGomb.style.opacity = "0.5";
            adottGomb.style.pointerEvents = "none";
            
            console.log("Gomb letiltva:", szam);
            console.log("Tiltott számok:", tiltottSzamok);
        }
    }
}

function Kuldes() {
    if(Kuldes) {
        if(kartyaszam.value.trim() != "" && 
           neve.value.trim() != "" && 
           hitkod.value.trim() != "" && 
           checkbok.checked != false) {
            
            tenylegesFizetesMenu.style.display = "none";
            
            if (adottGomb) {
                let szam = parseInt(adottGomb.querySelector('span').textContent);
                
                if (!tiltottSzamok.includes(szam)) {
                    tiltottSzamok.push(szam);
                }
                
                adottGomb.style.opacity = "0.5";
                adottGomb.style.pointerEvents = "none";
                
                console.log("Gomb véglegesen letiltva:", szam);
            }
        }
    }
}

function megsem() {
    if(megsem) {
        fizetesMenuGombok.style.display = "none";
    }
}

function Fizesz() {
    if(Fizesz) {
        fizetesMenuGombok.style.display = "none";
        tenylegesFizetesMenu.style.display = "block";
        
        
        kartyaSzam.value = "";
        neved.value = "";
        hitKod.value = "";
        lejDat.value = "";
        
        kartyaSzam.placeholder = "Kártyaszám";
        neved.placeholder = "Teljes név";
        hitKod.placeholder = "Hitelesítési kód";
        lejDat.placeholder = "Lejárati dátum";
        
        elfogadPipa.checked = false;
    }
}




generalGombok(1);
tolasErtek = 1;
console.log("Tombola indul...");